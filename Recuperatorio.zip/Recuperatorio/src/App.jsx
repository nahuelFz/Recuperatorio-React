import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './components/Home'; // Componente de inicio con las tarjetas de películas
import Login from './components/Login'; // Componente de inicio de sesión
import Movie from './components/Movie'; // Componente de detalles de la película

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home/>} />
                <Route path="/login" element={<Login/>} />
                <Route path="/movie/:id" element={<Movie/>} />
            </Routes>
        </Router>
    );
};

export default App;
